<?php include_once 'fileslogic2.php';?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>High school seninor face forum</title>
    <link rel="stylesheet" href="indexx.css">
</head>
<body>

<div class="wrapper">

<div class="features">
		<form action="indexx.php" method="POST" enctype="multipart/form-data">
	<h3> Upload Files</h3>
	<input type="file" name="myfile"><br>
	<a><button  type="submit" name="save">Upload</button></a>
		</form>

</div>
</div>
<h1><a href = "homepage1.php"><button  type="submit" name="save">home</button></a></h1>
   <h1>COURSES TO APPLY FOR</h1>
   <div id="courses">
	   <div class="cs">
		   <h3>Computer Science</h3>
		   <img src="cse.jpeg" width="50%" alt="cs">
		   <a href="computer.html" ><button class="apply">Apply Here</button></a>
	   </div>
	   <div class="business">
		   <h3>Business Studies</h3>
		   <img src="business.jpeg" alt="business">
		   <a href="#business.html" ><button class="apply">Apply Here</button></a>
	   </div>
	   <div class="journalism">
		   <h3>Media and Journalism</h3>
		   <img src="journalism.jpeg" alt="media">
		   <a href="#" ><button class="apply">Apply Here</button></a>
	   </div>
	   <div class="arts">
		   <h3>Arts & Humanities</h3>
		   <img src="arts.jpeg" alt="arts">
		   <a href="art.html" ><button class="apply">Apply Here</button></a>
	   </div>
	   <div class="medical">
		   <h3>Medical Science</h3>
		   <img src="medical.jpeg" alt="ms">
		   <a href="media.html" ><button class="apply">Apply Here</button></a>
	   </div>
   </div>
</showcase>
</body>
</html>









