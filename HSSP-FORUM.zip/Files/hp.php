</html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>School Web Template</title>
    <link rel="stylesheet" href="homepage.css">
</head>
<body>
   
   <div class="wrapper">
<!--NAVIGATION-->
       <nav>
       </nav>
<!--END OF NAVIGATION-->
      
      <div class="section">
          <p></p>
<!--FEATURES-->
         <div class="grade">
           <a href="Learner.php"><button>Grade 10</button></a> <br>
            <a href="Learner1.php" ><button>Grade 11</button></a><br>
            <a href="Learner3.php" ><button>Grade 12</button></a>
               
        </div>
    
         </div>
<!--END OF FEATURES-->
      </div>
<!--END OF SECTION-->
   </div>
<!--END OF WRAPPER-->
   
<!--SHOWCASE-->
   <showcase>
       <h1>COURSES TO APPLY FOR</h1>
       <div id="courses">
           <div class="cs">
               <h3>Computer Science</h3>
               <img src="cse.jpeg" width="50%" alt="cs">
               <a href="#" ><button class="apply">Apply Here</button></a>
           </div>
           <div class="business">
               <h3>Business Studies</h3>
               <img src="business.jpeg" alt="business">
               <a href="#" ><button class="apply">Apply Here</button></a>
           </div>
           <div class="journalism">
               <h3>Media and Journalism</h3>
               <img src="journalism.jpeg" alt="media">
               <a href="#" ><button class="apply">Apply Here</button></a>
           </div>
           <div class="arts">
               <h3>Arts & Humanities</h3>
               <img src="arts.jpeg" alt="arts">
               <a href="#" ><button class="apply">Apply Here</button></a>
           </div>
           <div class="medical">
               <h3>Medical Science</h3>
               <img src="medical.jpeg" alt="ms">
               <a href="#" ><button class="apply">Apply Here</button></a>
           </div>
       </div>
   </showcase>
<!--END OF SHOWCASE-->
</body>
</html>




