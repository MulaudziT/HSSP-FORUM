<?php include_once 'fileslogic.php';?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>High School Senir Phase Forum</title>
    <link rel="stylesheet" href="homepage.css">
</head>
<body>
<!--END OF NAVIGATION-->
<div class="wrapper">
      <div class="section">
<!--FEATURES-->

    <div class="features"   style="max-width:500px;margin: 10px auto;padding: 10px 20px; background: #f4f7f8; border-radius: 8px;">
	<table>
    <thead>
					<th>ID</th>
					<th>File Name</th>
                    <th>Size (in mb)</th>
					<th>Downloads</th>
					<th>Action</th>
				</thead>
				<tbody>
					<?php foreach($files as $file): ?>
					<tr>
						<td><?php echo $file['id'];?></td>
						<td><?php echo $file['name'];?></td>
						<td><?php echo $file['size'] /1000 . "KB";?></td>
						<td><?php echo $file['downloads'];?></td> 
						<td class = "apply">
							<a href="?file_id = <?php echo $file['id']?>">Download</a>
						</td>

					</tr>
					<?php endforeach ; ?>
				</tbody>
	</table>
    </div>

<!--END OF FEATURES-->
      </div>
<!--END OF SECTION-->
   </div>
</div>
<!--END OF WRAPPER-->
   
<!--SHOWCASE-->
   <showcase>
   <h1><a href = "homepage.php"><button  type="submit" name="save">home</button></a></h1>
       <h1>COURSES TO APPLY FOR</h1>
       <div id="courses">
           <div class="cs">
               <h3>Computer Science</h3>
               <img src="cse.jpeg" width="50%" alt="cs">
               <a href="computer" ><button class="apply">Apply Here</button></a>
           </div>
           <div class="business">
               <h3>Business Studies</h3>
               <img src="business.jpeg" alt="business">
               <a href="business" ><button class="apply">Apply Here</button></a>
           </div>
           <div class="journalism">
               <h3>Media and Journalism</h3>
               <img src="journalism.jpeg" alt="media">
               <a href="#" ><button class="apply">Apply Here</button></a>
           </div>
           <div class="arts">
               <h3>Arts & Humanities</h3>
               <img src="arts.jpeg" alt="arts">
               <a href="art" ><button class="apply">Apply Here</button></a>
           </div>
           <div class="medical">
               <h3>Medical Science</h3>
               <img src="medical.jpeg" alt="ms">
               <a href="media" ><button class="apply">Apply Here</button></a>
           </div>
       </div>
   </showcase>
</body>
</html>
